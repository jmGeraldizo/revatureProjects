import path from 'path';

const publicDir = path.join(__dirname, '../public');

export default publicDir;