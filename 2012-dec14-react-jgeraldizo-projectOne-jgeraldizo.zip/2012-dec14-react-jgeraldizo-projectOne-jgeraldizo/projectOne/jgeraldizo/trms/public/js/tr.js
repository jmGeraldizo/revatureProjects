// window <- An object representation of (essentially) the browser
window.onload = () => { // The onload event triggers after the webpage is finished loading.
    // document <- An object representation of the DOM.
    //ajaxGetRestaurants();
    //createRestaurantList(restaurants);
    createNavBar();
    //document.getElementById('addRestLink').onclick= addRestaurantForm;
    fetchGetClaims();
    authenticate();
}
function fetchGetClaims(){
    // Fetch is an API for sending requests to servers that utilizes promises.
    fetch('/claims').then((resp)=> {
            // The data that gets passed into the promise is basically a response object.
            // the response object has metadata (like the status code) and the body of the response
            // as well as useful methods like .json() which will create a promise with the data
            // as an object.
            return resp.json();
        }).then(data => createClaimList(data));
}

function createClaimList(claimList){
    let section = document.getElementById('restaurants');
    let row;
    for(let i = 0; i < restaurantList.length; i++) {
        if(i%3 === 0) {
            row = document.createElement('section');
            row.className='row border';
            section.appendChild(row);
        }
        let div = createRestaurantElement('div', '', 'col restaurant card', row);
        let img = document.createElement('img');
        img.src = restaurantList[i].img;
        img.className = 'card-img-top rest-logo';
        div.appendChild(img);
        let card = document.createElement('div');
        card.className="card-body";
        div.appendChild(card);
        createRestaurantElement('p', restaurantList[i].name, '', card);
        createRestaurantElement('p', restaurantList[i].eta, 'deliverytime', card);
        createRestaurantElement('p', restaurantList[i].rating, 'rating', card);
        createRestaurantElement('p', restaurantList[i].type, 'foodtype', card);
    }
}
function createRestaurantElement(element, data, className, parent){
    let e = document.createElement(element);
    e.innerHTML = data;
    e.className = className;
    parent.appendChild(e);
    return e;
}
let createLiteral = (rest) => {
    return `<div class="restaurant">
    <p>${rest.name}</p>
    <img src="${rest.img}"/>
    <p class="deliverytime">${rest.eta}</p>
    <p class="rating">${rest.rating} stars</p>
    <p class="foodtype">${rest.type}</p>
    </div>`
}
