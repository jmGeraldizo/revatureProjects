export class TRForm {
    employee_name: string = '';
    date: string = '';
    time: string = '';
    location: string = '';
    description: string = '';
    cost: number = 0;
    event_type: string = '';
    grading: string = '';
    justification: string = '';
    status: string = 'pending';
}
