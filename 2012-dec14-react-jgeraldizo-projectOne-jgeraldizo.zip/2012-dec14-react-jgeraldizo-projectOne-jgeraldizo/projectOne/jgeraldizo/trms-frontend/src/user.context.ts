import React from 'react';

const context = React.createContext<any[]>([]);

export default context;
